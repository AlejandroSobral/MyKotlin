<h1> Desarrollo de Aplicaciones Móviles - 2023 - 1er cuatrimestre </h1>

* UTN.FRBA
* Alejandro Sobral.

# FirstApp

An App with Football Clubs information. Nothing relevant.

* Login:
  * user: test
  * password: test

