package com.utn.firstapp.entities

enum class State {
    LOADING,
    SUCCESS,
    FAILURE
}