package com.utn.firstapp


import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class FifaApp:Application()